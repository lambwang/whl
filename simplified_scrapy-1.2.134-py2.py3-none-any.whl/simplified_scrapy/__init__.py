#!/usr/bin/python
# -*- coding: UTF-8 -*-
from simplified_scrapy.core.spider import Spider
from simplified_scrapy.simplified_doc import SimplifiedDoc
from simplified_scrapy.request import Request,req
from simplified_scrapy.core import utils
from simplified_scrapy.simplified_main import SimplifiedMain
name = "simplified_scrapy"
# if __name__ == '__main__':
#     printInfo('run simplified-scrapy as main app......')
# else:
#     printInfo('simplified-scrapy init......')
