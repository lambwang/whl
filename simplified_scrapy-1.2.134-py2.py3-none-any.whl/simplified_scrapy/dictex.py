#!/usr/bin/python
#coding=utf-8
import sys
from simplified_scrapy.core.dictex import Dict as dic
class Dict(dic):
  pass
