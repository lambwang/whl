#!/usr/bin/python
# -*- coding: UTF-8 -*-
name = "simplified_scrapy_core"
from simplified_scrapy.core.objstore_base import ObjStoreBase
from simplified_scrapy.core.htmlstore_base import HtmlStoreBase
from simplified_scrapy.core.urlstore_base import UrlStoreBase
from simplified_scrapy.core.cookiestroe_base import CookieStoreBase