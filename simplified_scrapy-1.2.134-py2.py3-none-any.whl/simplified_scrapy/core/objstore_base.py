#!/usr/bin/python
#coding=utf-8
class ObjStoreBase:
  def saveObj(self, data):
    raise NotImplementedError