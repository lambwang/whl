from simplified_scrapy.core.spider import Spider# as SP
from simplified_scrapy.simplified_doc import SimplifiedDoc
# class Spider(SP):
#   pass