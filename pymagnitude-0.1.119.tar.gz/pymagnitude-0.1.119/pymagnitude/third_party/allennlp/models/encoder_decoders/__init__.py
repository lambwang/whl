
from __future__ import absolute_import
from allennlp.models.encoder_decoders.simple_seq2seq import SimpleSeq2Seq
